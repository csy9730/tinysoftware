namespace System.Windows.Forms {
public interface IPersist
{

	// Methods
	public abstract virtual void GetClassID(out System.Guid& pClassID) {}
}

}
