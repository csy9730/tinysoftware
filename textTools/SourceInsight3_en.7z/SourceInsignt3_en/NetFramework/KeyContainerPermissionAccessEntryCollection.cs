namespace System.Security.Permissions {
public class KeyContainerPermissionAccessEntryCollection : System.Collections.ICollection, System.Collections.IEnumerable
{

	// Methods
	public int Add(KeyContainerPermissionAccessEntry accessEntry) {}
	public void Clear() {}
	public int IndexOf(KeyContainerPermissionAccessEntry accessEntry) {}
	public void Remove(KeyContainerPermissionAccessEntry accessEntry) {}
	public KeyContainerPermissionAccessEntryEnumerator GetEnumerator() {}
	public void CopyTo(KeyContainerPermissionAccessEntry[] array, int index) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public KeyContainerPermissionAccessEntry Item { get{} }
	public int Count { get{} }
	public bool IsSynchronized { get{} }
	public object SyncRoot { get{} }
}

}
