namespace System.Runtime.CompilerServices {
public class CallConvFastcall
{

	// Constructors
	public CallConvFastcall() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
