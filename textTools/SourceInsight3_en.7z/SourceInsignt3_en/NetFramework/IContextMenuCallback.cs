namespace Microsoft.Aspnet.Snapin {
public interface IContextMenuCallback
{

	// Methods
	public abstract virtual int AddItem(CONTEXTMENUITEM& pItem) {}
}

}
