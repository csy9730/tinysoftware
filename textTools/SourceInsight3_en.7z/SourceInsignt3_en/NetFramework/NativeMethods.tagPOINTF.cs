namespace System.Windows.Forms {
public class tagPOINTF
{

	// Constructors
	public tagPOINTF() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public float x;
	public float y;
}

}
