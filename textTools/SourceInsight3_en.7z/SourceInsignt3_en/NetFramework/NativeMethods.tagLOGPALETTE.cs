namespace System.Design {
public class tagLOGPALETTE
{

	// Constructors
	public tagLOGPALETTE() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public short palVersion;
	public short palNumEntries;
}

}
