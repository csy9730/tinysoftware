namespace System.Windows.Forms {
public interface ICommandExecutor
{

	// Methods
	public abstract virtual void Execute() {}
}

}
