namespace System.Web.Mobile {
public class ErrorHandlerModule : System.Web.IHttpModule
{

	// Constructors
	public ErrorHandlerModule() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
