namespace System.Windows.Forms {
public class tagCAUUID
{

	// Constructors
	public tagCAUUID() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public int cElems;
	public System.IntPtr pElems;
}

}
