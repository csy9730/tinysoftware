namespace System.Configuration.Install {
public class ManagedInstallerClass : IManagedInstaller
{

	// Constructors
	public ManagedInstallerClass() {}

	// Methods
	public static void InstallHelper(string[] args) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
