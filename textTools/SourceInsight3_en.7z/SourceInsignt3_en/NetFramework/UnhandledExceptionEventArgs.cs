namespace System {
public class UnhandledExceptionEventArgs : EventArgs
{

	// Constructors
	public UnhandledExceptionEventArgs(object exception, bool isTerminating) {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public object ExceptionObject { get{} }
	public bool IsTerminating { get{} }
}

}
