namespace System.ComponentModel {
public interface INestedContainer : IContainer, System.IDisposable
{

	// Properties
	public IComponent Owner { get{} }
}

}
