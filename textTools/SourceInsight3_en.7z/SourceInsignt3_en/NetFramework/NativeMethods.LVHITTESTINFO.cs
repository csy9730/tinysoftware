namespace System.Windows.Forms {
public class LVHITTESTINFO
{

	// Constructors
	public LVHITTESTINFO() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public int pt_x;
	public int pt_y;
	public int flags;
	public int iItem;
	public int iSubItem;
}

}
