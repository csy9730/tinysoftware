namespace System.Runtime.Remoting.Metadata.W3cXsd2001 {
public class SoapMonth : ISoapXsd
{

	// Constructors
	public SoapMonth() {}
	public SoapMonth(System.DateTime value) {}

	// Methods
	public virtual string GetXsdType() {}
	public virtual string ToString() {}
	public static SoapMonth Parse(string value) {}
	public Type GetType() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public string XsdType { get{} }
	public System.DateTime Value { get{} set{} }
}

}
