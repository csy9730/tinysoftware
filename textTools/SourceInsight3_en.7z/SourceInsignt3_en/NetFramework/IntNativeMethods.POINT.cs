namespace System.Drawing.Internal {
public class POINT
{

	// Constructors
	public POINT() {}
	public POINT(int x, int y) {}

	// Methods
	public System.Drawing.Point ToPoint() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public int x;
	public int y;
}

}
