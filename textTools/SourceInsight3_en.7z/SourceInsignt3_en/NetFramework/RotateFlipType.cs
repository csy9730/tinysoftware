namespace System.Drawing {
public class RotateFlipType : System.Enum, System.IComparable, System.IFormattable, System.IConvertible
{

	// Methods
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
	public virtual string ToString() {}
	public virtual string ToString(string format, System.IFormatProvider provider) {}
	public virtual int CompareTo(object target) {}
	public virtual string ToString(System.IFormatProvider provider) {}
	public virtual System.TypeCode GetTypeCode() {}
	public string ToString(string format) {}
	public Type GetType() {}

	// Fields
	public int value__;
	public RotateFlipType RotateNoneFlipNone;
	public RotateFlipType Rotate90FlipNone;
	public RotateFlipType Rotate180FlipNone;
	public RotateFlipType Rotate270FlipNone;
	public RotateFlipType RotateNoneFlipX;
	public RotateFlipType Rotate90FlipX;
	public RotateFlipType Rotate180FlipX;
	public RotateFlipType Rotate270FlipX;
	public RotateFlipType RotateNoneFlipY;
	public RotateFlipType Rotate90FlipY;
	public RotateFlipType Rotate180FlipY;
	public RotateFlipType Rotate270FlipY;
	public RotateFlipType RotateNoneFlipXY;
	public RotateFlipType Rotate90FlipXY;
	public RotateFlipType Rotate180FlipXY;
	public RotateFlipType Rotate270FlipXY;
}

}
