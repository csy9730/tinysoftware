namespace System.Web.UI {
public class WebServiceParser : SimpleWebHandlerParser, IAssemblyDependencyParser
{

	// Methods
	public static Type GetCompiledType(string inputFile, System.Web.HttpContext context) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
