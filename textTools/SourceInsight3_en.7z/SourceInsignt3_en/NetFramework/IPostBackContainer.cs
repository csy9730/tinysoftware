namespace System.Web.UI.WebControls {
public interface IPostBackContainer
{

	// Methods
	public abstract virtual System.Web.UI.PostBackOptions GetPostBackOptions(IButtonControl buttonControl) {}
}

}
