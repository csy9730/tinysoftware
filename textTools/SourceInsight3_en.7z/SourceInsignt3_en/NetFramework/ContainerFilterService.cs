namespace System.ComponentModel {
public class ContainerFilterService
{

	// Methods
	public virtual ComponentCollection FilterComponents(ComponentCollection components) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
