namespace Microsoft.Vsa {
public interface IVsaDTCodeItem
{

	// Properties
	public bool CanDelete { get{} set{} }
	public bool CanMove { get{} set{} }
	public bool CanRename { get{} set{} }
	public bool Hidden { get{} set{} }
	public bool ReadOnly { get{} set{} }
}

}
