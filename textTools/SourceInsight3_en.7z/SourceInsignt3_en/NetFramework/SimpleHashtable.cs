namespace Microsoft.JScript {
public class SimpleHashtable
{

	// Constructors
	public SimpleHashtable(uint threshold) {}

	// Methods
	public System.Collections.IDictionaryEnumerator GetEnumerator() {}
	public void Remove(object key) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public object Item { get{} set{} }
}

}
