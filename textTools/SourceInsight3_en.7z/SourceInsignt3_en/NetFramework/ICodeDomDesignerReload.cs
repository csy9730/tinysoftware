namespace System.ComponentModel.Design.Serialization {
public interface ICodeDomDesignerReload
{

	// Methods
	public abstract virtual bool ShouldReloadDesigner(System.CodeDom.CodeCompileUnit newTree) {}
}

}
