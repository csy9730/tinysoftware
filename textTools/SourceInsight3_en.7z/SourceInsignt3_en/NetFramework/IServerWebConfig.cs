namespace System.EnterpriseServices.Internal {
public interface IServerWebConfig
{

	// Methods
	public abstract virtual void AddElement(string FilePath, string AssemblyName, string TypeName, string ProgId, string Modeout , System.String& Error) {}
	public abstract virtual void Create(string FilePath, string FileRootNameout , System.String& Error) {}
}

}
