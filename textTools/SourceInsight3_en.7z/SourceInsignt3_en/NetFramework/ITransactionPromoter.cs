namespace System.Transactions {
public interface ITransactionPromoter
{

	// Methods
	public abstract virtual byte[] Promote() {}
}

}
