namespace System.Windows.Forms {
public interface ISpecifyPropertyPages
{

	// Methods
	public abstract virtual void GetPages(out tagCAUUID pPages) {}
}

}
