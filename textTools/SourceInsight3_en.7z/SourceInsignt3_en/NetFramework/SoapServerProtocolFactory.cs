namespace System.Web.Services.Protocols {
public class SoapServerProtocolFactory : ServerProtocolFactory
{

	// Constructors
	public SoapServerProtocolFactory() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
