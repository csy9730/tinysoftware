namespace System.Windows.Forms {
public class DockPaddingEdges : System.ICloneable
{

	// Methods
	public virtual bool Equals(object other) {}
	public virtual int GetHashCode() {}
	public virtual string ToString() {}
	public Type GetType() {}

	// Properties
	public int All { get{} set{} }
	public int Bottom { get{} set{} }
	public int Left { get{} set{} }
	public int Right { get{} set{} }
	public int Top { get{} set{} }
}

}
