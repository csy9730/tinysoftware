namespace System.Configuration {
public class DictionarySectionHandler : IConfigurationSectionHandler
{

	// Constructors
	public DictionarySectionHandler() {}

	// Methods
	public virtual object Create(object parent, object context, System.Xml.XmlNode section) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
