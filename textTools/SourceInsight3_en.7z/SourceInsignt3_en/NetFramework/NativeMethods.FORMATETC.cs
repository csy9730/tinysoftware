namespace System.Design {
public class FORMATETC
{

	// Constructors
	public FORMATETC() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public int cfFormat;
	public System.IntPtr ptd;
	public int dwAspect;
	public int lindex;
	public int tymed;
}

}
