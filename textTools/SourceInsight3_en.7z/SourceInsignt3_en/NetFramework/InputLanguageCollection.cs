namespace System.Windows.Forms {
public class InputLanguageCollection : System.Collections.ReadOnlyCollectionBase, System.Collections.ICollection, System.Collections.IEnumerable
{

	// Methods
	public bool Contains(InputLanguage value) {}
	public void CopyTo(InputLanguage[] array, int index) {}
	public int IndexOf(InputLanguage value) {}
	public virtual System.Collections.IEnumerator GetEnumerator() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public InputLanguage Item { get{} }
	public int Count { get{} }
}

}
