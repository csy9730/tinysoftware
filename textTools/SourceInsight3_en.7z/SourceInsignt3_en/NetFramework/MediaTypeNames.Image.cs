namespace System.Net.Mime {
public class Image
{

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public string Gif;
	public string Tiff;
	public string Jpeg;
}

}
