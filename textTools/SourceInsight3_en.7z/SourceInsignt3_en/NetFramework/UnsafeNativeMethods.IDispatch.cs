namespace Microsoft.VisualBasic.CompilerServices {
public interface IDispatch
{

	// Methods
	public abstract virtual int GetTypeInfoCount() {}
	public abstract virtual int GetTypeInfo(int index, int lcidout , ITypeInfo& pTypeInfo) {}
	public abstract virtual int GetIDsOfNames() {}
	public abstract virtual int Invoke() {}
}

}
