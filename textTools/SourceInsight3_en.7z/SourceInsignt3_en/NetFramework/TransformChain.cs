namespace System.Security.Cryptography.Xml {
public class TransformChain
{

	// Constructors
	public TransformChain() {}

	// Methods
	public void Add(Transform transform) {}
	public System.Collections.IEnumerator GetEnumerator() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public int Count { get{} }
	public Transform Item { get{} }
}

}
