namespace Microsoft.JScript {
public class Eval : AST
{

	// Methods
	public static object JScriptEvaluate(object source, Microsoft.JScript.Vsa.VsaEngine engine) {}
	public static object JScriptEvaluate(object source, object unsafeOption, Microsoft.JScript.Vsa.VsaEngine engine) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
