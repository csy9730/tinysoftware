namespace System {
public interface IComparable<T>
{

	// Methods
	public abstract virtual int CompareTo(T other) {}
}

}
