namespace System.Web.UI {
public interface ITemplate
{

	// Methods
	public abstract virtual void InstantiateIn(Control container) {}
}

}
