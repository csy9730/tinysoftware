namespace System.Xml {
public interface IHasXmlNode
{

	// Methods
	public abstract virtual XmlNode GetNode() {}
}

}
