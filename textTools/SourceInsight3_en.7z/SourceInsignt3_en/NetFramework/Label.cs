namespace System.Reflection.Emit {
public class Label : System.ValueType
{

	// Methods
	public virtual int GetHashCode() {}
	public virtual bool Equals(object obj) {}
	public bool Equals(Label obj) {}
	public static bool op_Equality(Label a, Label b) {}
	public static bool op_Inequality(Label a, Label b) {}
	public virtual string ToString() {}
	public Type GetType() {}
}

}
