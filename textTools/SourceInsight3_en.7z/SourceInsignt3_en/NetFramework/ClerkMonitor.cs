namespace System.EnterpriseServices.CompensatingResourceManager {
public class ClerkMonitor : System.Collections.IEnumerable
{

	// Constructors
	public ClerkMonitor() {}

	// Methods
	public void Populate() {}
	public virtual System.Collections.IEnumerator GetEnumerator() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public int Count { get{} }
	public ClerkInfo Item { get{} }
	public ClerkInfo Item { get{} }
}

}
