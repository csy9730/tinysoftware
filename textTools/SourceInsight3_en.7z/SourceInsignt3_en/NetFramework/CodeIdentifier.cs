namespace System.Xml.Serialization {
public class CodeIdentifier
{

	// Constructors
	public CodeIdentifier() {}

	// Methods
	public static string MakePascal(string identifier) {}
	public static string MakeCamel(string identifier) {}
	public static string MakeValid(string identifier) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
